# class and defs for processing the CryoSat tracks into DOT
import numpy as np
import pandas as pd
import data_year as dy
import grid_set as gs
import datetime
import copy
import itertools
import glob
import shutil
import os
import sys
import gc
import psutil
sys.path.insert(0, '/Users/H/WAVES/geo_data_group/')
import grid_set as gs
from invoke import run
from numba import jit
from scipy import stats
from dateutil.relativedelta import relativedelta
from mpl_toolkits.basemap import Basemap

class grid_currents(gs.grid_set):
# will make one of these at a time point (as a datetime) defined by timestart
# then process through the length of period (a time delta/or 'month' 'month/4' '10day' option)
# then write what we've done with the tracks (options needed here np/netcdf/etc)
# then dump them
# optional current processing and saving too
# optional multiple geoids to process from
# then update the time point by length period (initally from time period)
    def __init__(self,period,time_start,mplot):
        super().__init__(mplot)
        self.time = time_start
        self.period = period 
        # here we can do clever time period stuff 
        # to make sure we fill months/years correctly
        self.files = False
        self.saved = False
        self.grid = False
        self.gridinfo = False
        self.masked = False
        self.data = False

    def find_offsets(self,off_dir,extension,set_time = False,n_t = 0,dbug = False):
        # gets a file list from a directory,
        # from what it finds get a n_t and time vec
        # files need to be slightly consistent with the class period
        files = glob.glob(off_dir+'*.npz')
        self.n_t = 0
        self.dates = []
        for file in files: 
            if dbug: print(file) 
            try:
                date_str = file.split('save_')[1]
                date_str = date_str.split(extension)[0]
                date_use = datetime.datetime.strptime(date_str,'%Y%m%d')
                if dbug: print(date_str) 
            except ValueError:
                pass
            except IndexError:
                pass
            else:
                self.n_t += 1
                self.dates.append(date_use)
        self.dates.sort()
        print('Year 0 = ',self.time.year,', File year 0 = ',self.dates[0].year)
        # have a sorted array of dates - now need a years range
        self.nyrs = self.dates[-1].year - self.dates[0].year + 1
        # make yrs/mnths index array for the data
        self.yrmnth = np.ma.empty([self.nyrs,12],dtype = int)
        self.yrmnth[:,:] = -1
        for tt in range(self.n_t):
            yr = self.dates[tt].year - self.dates[0].year 
            mt = self.dates[tt].month - 1
#             print(yr,mt,tt)
            self.yrmnth[yr,mt] = tt
        self.yrmnth.mask = self.yrmnth < 0
        self.files = True

    def load_offsets(self,off_dir):
        if self.files:
            # make the arrays
            # get grid dimensions if we don't have them aleady
            if ~self.grid:
                file= off_dir+"offset_save_"+self.dates[0].strftime('%Y%m%d')+".npz"
                with np.load(file) as npzfile:
                    self.dxRes = npzfile["dxRes"]
                    self.dyRes = npzfile["dyRes"]
                    self.m = npzfile["m"]
                    self.n = npzfile["n"]
            
            self.LRM_DOT_bin = np.empty([self.n_t,self.m,self.n])
            self.SAR_o_DOT_bin = np.empty([self.n_t,self.m,self.n])
            self.SAR_l_DOT_bin = np.empty([self.n_t,self.m,self.n])
            self.SARIN_DOT_bin = np.empty([self.n_t,self.m,self.n])
            self.LRM_sla_bin_count = np.empty([self.n_t,self.m,self.n])
            self.SAR_o_sla_bin_count = np.empty([self.n_t,self.m,self.n])
            self.SAR_l_sla_bin_count = np.empty([self.n_t,self.m,self.n])
            self.SARIN_sla_bin_count = np.empty([self.n_t,self.m,self.n])
            self.SAR_o_offset = np.empty([self.n_t,self.m,self.n])
            self.SAR_l_offset = np.empty([self.n_t,self.m,self.n])
            self.SARIN_offset = np.empty([self.n_t,self.m,self.n])
            
            for tt,date in enumerate(self.dates):
                file= off_dir+"offset_save_"+date.strftime('%Y%m%d')+".npz"
                with np.load(file) as npzfile:
                    self.LRM_DOT_bin[tt,:,:] = npzfile["LRM_DOT_bin"]
                    self.SAR_o_DOT_bin[tt,:,:] = npzfile["SAR_o_DOT_bin"]
                    self.SAR_l_DOT_bin[tt,:,:] = npzfile["SAR_l_DOT_bin"]
                    self.SARIN_DOT_bin[tt,:,:] = npzfile["SARIN_DOT_bin"]
                    self.LRM_sla_bin_count[tt,:,:] = npzfile["LRM_sla_bin_count"]
                    self.SAR_o_sla_bin_count[tt,:,:] = npzfile["SAR_o_sla_bin_count"]
                    self.SAR_l_sla_bin_count[tt,:,:] = npzfile["SAR_l_sla_bin_count"]
                    self.SARIN_sla_bin_count[tt,:,:] = npzfile["SARIN_sla_bin_count"]
                    self.SAR_o_offset[tt,:,:] = npzfile["SAR_o_offset"]
                    self.SAR_l_offset[tt,:,:] = npzfile["SAR_l_offset"]
                    self.SARIN_offset[tt,:,:] = npzfile["SARIN_offset"]
            self.data = True
        else: print('no files found, so how can I load them in???')

    def save_offset_time(self,save_dir,extension = '.npz'):
        # for the grouped offset arrays, what is the needed offset?
        # can take median of each month -  or mean fltering +-2 std
        # 
        if self.data & self.masked:
            self.SAR_o_off_t = np.empty([self.nyrs,12])
            self.SAR_l_off_t = np.empty([self.nyrs,12])
            self.SARIN_off_t = np.empty([self.nyrs,12])
            self.SAR_o_off_t[:,:] = np.nan
            self.SAR_l_off_t[:,:] = np.nan
            self.SARIN_off_t[:,:] = np.nan
            self.SAR_o_off_c = np.empty([12])
            self.SAR_l_off_c = np.empty([12])
            self.SARIN_off_c = np.empty([12])
            self.SAR_o_off_c[:] = np.nan
            self.SAR_l_off_c[:] = np.nan
            self.SARIN_off_c[:] = np.nan
            for yr in range(self.nyrs):
                for mn in range(12):
                    if ~self.yrmnth.mask[yr,mn]:
                        idx = self.yrmnth[yr,mn]
                        self.SAR_o_off_t[yr,mn] = np.nanmedian(self.SAR_o_offset[idx][self.mask>0])
                        self.SAR_l_off_t[yr,mn] = np.nanmedian(self.SAR_l_offset[idx][self.mask>0])
                        self.SARIN_off_t[yr,mn] = np.nanmedian(self.SARIN_offset[idx][self.mask>0])
            for mn in range(12):
                idx = self.yrmnth[:,mn].compressed()
                self.SAR_o_off_c[mn] = np.nanmedian([self.SAR_o_offset[i][self.mask>0] for i in idx])
                self.SAR_l_off_c[mn] = np.nanmedian([self.SAR_l_offset[i][self.mask>0] for i in idx])
                self.SARIN_off_c[mn] = np.nanmedian([self.SARIN_offset[i][self.mask>0] for i in idx])
#         self.SAR_o_off_c = np.nanmean(SAR_o_off_t,axis = 0)
#         self.SAR_l_off_c = np.nanmean(SAR_l_off_t,axis = 0)
#         self.SARIN_off_c = np.nanmean(SARIN_off_t,axis = 0)
            save_file = self.dates[0].strftime('%Y%m%d')+'_'+self.dates[-1].strftime('%Y%m%d')+extension
            np.savez(save_dir+save_file,
                SAR_o_off_t= self.SAR_o_off_t,
                SAR_l_off_t= self.SAR_l_off_t,
                SARIN_off_t= self.SARIN_off_t,
                SAR_o_off_c= self.SAR_o_off_c,
                SAR_l_off_c= self.SAR_l_off_c,
                SARIN_off_c= self.SARIN_off_c,
                yrmnth = self.yrmnth)
            print("Offset time series saved in "+save_dir+save_file)
        else:
            print("No offsets to save, so none were saved")

            
    def calc_offset_time(self,file):
        if self.data & self.masked:
            self.SAR_o_off_t = np.empty([self.nyrs,12])
            self.SAR_l_off_t = np.empty([self.nyrs,12])
            self.SARIN_off_t = np.empty([self.nyrs,12])
            self.SAR_o_off_t[:,:] = np.nan
            self.SAR_l_off_t[:,:] = np.nan
            self.SARIN_off_t[:,:] = np.nan
            self.SAR_o_off_c = np.empty([12])
            self.SAR_l_off_c = np.empty([12])
            self.SARIN_off_c = np.empty([12])
            self.SAR_o_off_c[:] = np.nan
            self.SAR_l_off_c[:] = np.nan
            self.SARIN_off_c[:] = np.nan
            for yr in range(self.nyrs):
                for mn in range(12):
                    if ~self.yrmnth.mask[yr,mn]:
                        idx = self.yrmnth[yr,mn].data()
                        self.SAR_o_off_t[yr,mn] = np.nanmedian(self.SAR_o_offset[idx][self.mask>0])
                        self.SAR_l_off_t[yr,mn] = np.nanmedian(self.SAR_l_offset[idx][self.mask>0])
                        self.SARIN_off_t[yr,mn] = np.nanmedian(self.SARIN_offset[idx][self.mask>0])
            for mn in range(12):
                idx = self.yrmnth[:,mn].compressed()
                self.SAR_o_off_c[mn] = np.nanmedian([self.SAR_o_offset[i][self.mask>0] for i in idx])
                self.SAR_l_off_c[mn] = np.nanmedian([self.SAR_l_offset[i][self.mask>0] for i in idx])
                self.SARIN_off_c[mn] = np.nanmedian([self.SARIN_offset[i][self.mask>0] for i in idx])
#         self.SAR_o_off_c = np.nanmean(SAR_o_off_t,axis = 0)
#         self.SAR_l_off_c = np.nanmean(SAR_l_off_t,axis = 0)
#         self.SARIN_off_c = np.nanmean(SARIN_off_t,axis = 0)
            
        print('SAR_o offset mean = ',np.nanmean(self.SAR_l_off_c))
        print('SAR_l offset mean = ',np.nanmean(self.SAR_l_off_c))
        print('SARIN offset mean = ',np.nanmean(self.SARIN_off_c))


    def load_offset_time(self,file):
        # take the loaded files, make a yrs/mnths array of median offsets
        with np.load(file) as npzfile:
            self.SAR_o_off_t= npzfile["SAR_o_off_t"]
            self.SAR_l_off_t= npzfile["SAR_l_off_t"]
            self.SARIN_off_t= npzfile["SARIN_off_t"]
            self.SAR_o_off_c= npzfile["SAR_o_off_c"]
            self.SAR_l_off_c= npzfile["SAR_l_off_c"]
            self.SARIN_off_c= npzfile["SARIN_off_c"]
            self.yrmnth = npzfile["yrmnth"]
#         self.SAR_o_off_c = np.nanmean(SAR_o_off_t,axis = 0)
#         self.SAR_l_off_c = np.nanmean(SAR_l_off_t,axis = 0)
#         self.SARIN_off_c = np.nanmean(SARIN_off_t,axis = 0)
            
        print('SAR_o offset mean = ',np.nanmean(self.SAR_l_off_c))
        print('SAR_l offset mean = ',np.nanmean(self.SAR_o_off_c))
        print('SARIN offset mean = ',np.nanmean(self.SARIN_off_c))


    def mode_masks(self,save=False,file = ''):
        """
        Creates 4 different 2d masks, canbe saved in 'file'
        this removes annoying 'different' modes prior to smoothing of the DOT
        """
        total_w = (self.LRM_sla_bin_count+
                   self.SAR_o_sla_bin_count+
                   self.SAR_l_sla_bin_count+
                   self.SARIN_sla_bin_count)
        LRM___w = self.LRM_sla_bin_count/total_w
        SAR_o_w = self.SAR_o_sla_bin_count/total_w
        SAR_l_w = self.SAR_l_sla_bin_count/total_w
        SARIN_w = self.SARIN_sla_bin_count/total_w
        self.LRM___mask = np.log(np.nanmean(LRM___w,axis=0))>-3
        self.SAR_o_mask = np.log(np.nanmean(SAR_o_w,axis=0))>-3
        self.SAR_l_mask = np.log(np.nanmean(SAR_l_w,axis=0))>-3
        self.SARIN_mask = np.log(np.nanmean(SARIN_w,axis=0))>-4
        if save:
            np.savez(file,
                LRM___mask = self.LRM___mask,
                SAR_o_mask = self.SAR_o_mask,
                SAR_l_mask = self.SAR_l_mask,
                SARIN_mask = self.SARIN_mask,
                m = self.m,
                n = self.n)
        

    def load_mode_masks(self,file):
        with np.load(file) as npzfile:
            self.LRM___mask = npzfile["LRM___mask"]
            self.SAR_o_mask = npzfile["SAR_o_mask"]
            self.SAR_l_mask = npzfile["SAR_l_mask"]
            self.SARIN_mask = npzfile["SARIN_mask"]
            m_check = npzfile["m"]
            n_check = npzfile["n"]
        print('Data size = ',self.m,self.n,', mask size = ',m_check,n_check)
            
                        
                        
    def get_weights_DOT(self,weight_lim = 1,save_w=False,
        mode_mask=False):
        """
        Added a weight lim to filter data holes a little better
        Also save weight and mode mask flags.
        Save_weight so to create the mode mask -  see other methods
        mode_mask = True to use mode mask when processing DOT
        """
        total_w = (self.LRM_sla_bin_count+
                   self.SAR_o_sla_bin_count+
                   self.SAR_l_sla_bin_count+
                   self.SARIN_sla_bin_count)
        LRM___w = self.LRM_sla_bin_count/total_w
        SAR_o_w = self.SAR_o_sla_bin_count/total_w
        SAR_l_w = self.SAR_l_sla_bin_count/total_w
        SARIN_w = self.SARIN_sla_bin_count/total_w
        if save_w:
            self.LRM___w = LRM___w
            self.SAR_o_w = SAR_o_w
            self.SAR_l_w = SAR_l_w
            self.SARIN_w = SARIN_w
            self.total_w = total_w
        if mode_mask:
            LRM___mask = self.LRM___mask
            SAR_o_mask = self.SAR_o_mask
            SAR_l_mask = self.SAR_l_mask
            SARIN_mask = self.SARIN_mask
        else:
            LRM___mask = np.ones([self.m,self.n])
            SAR_o_mask = np.ones([self.m,self.n])
            SAR_l_mask = np.ones([self.m,self.n])
            SARIN_mask = np.ones([self.m,self.n])
        LRM__dw = self.LRM_DOT_bin.copy()
        SAR_odw = self.SAR_o_DOT_bin.copy()
        SAR_ldw = self.SAR_l_DOT_bin.copy()
        SARINdw = self.SARIN_DOT_bin.copy()
        LRM__dw = LRM__dw*LRM___w
        SAR_odw = SAR_odw*SAR_o_w
        SAR_ldw = SAR_ldw*SAR_l_w
        SARINdw = SARINdw*SARIN_w
        LRM__dw[np.isnan(LRM__dw)] = 0.0
        SAR_odw[np.isnan(SAR_odw)] = 0.0
        SAR_ldw[np.isnan(SAR_ldw)] = 0.0
        SARINdw[np.isnan(SARINdw)] = 0.0
        SAR_o_w[np.isnan(SAR_o_w)] = 0.0
        SAR_l_w[np.isnan(SAR_l_w)] = 0.0
        SARIN_w[np.isnan(SARIN_w)] = 0.0
        temp_mask = np.ones([self.n_t,self.m,self.n],dtype = bool)
        # make sure there were enough binned data to use
        temp_mask[total_w<weight_lim] = False
#         for i in range(self.m):
#             for j in range(self.n):
#                 if total_w[:,i,j]<1: temp_mask[i,j] = np.nan
        temp_DOT = np.empty([self.n_t,self.m,self.n])
        for tt in range(self.n_t):
            mn = self.dates[tt].month - 1
            temp_DOT[tt]= (LRM__dw[tt]*LRM___mask+ 
                    SAR_odw[tt]*SAR_o_mask + 
                        self.SAR_o_off_c[mn]*SAR_o_w[tt]*SAR_o_mask +
                    SAR_ldw[tt]*SAR_l_mask+ 
                        (self.SAR_o_off_c[mn]
                        +self.SAR_l_off_c[mn])*SAR_l_w[tt]*SAR_l_mask+
                    SARINdw[tt]*SARIN_mask+ 
                        (self.SAR_o_off_c[mn]+self.SAR_l_off_c[mn]
                        +self.SARIN_off_c[mn])*SARIN_w[tt]*SARIN_mask)
        self.DOT= dy.data_year(temp_DOT,self.dates)
        self.DOT.build_mask()
        self.DOT.mask = temp_mask
        
        
        
    def filt_DOT(self,radius,limits,mask=True,n_use = [0,True]):
        # set up arrays
        DOT_filt = np.empty([self.DOT.n_t,self.DOT.m,self.DOT.n])
        temp_mask = np.ones([self.DOT.m,self.DOT.n])
        # set up limits
        if type(n_use[1]) == bool:
            n_use[1] = self.DOT.n_t
        for i in range(n_use[0],n_use[1]):
            temp_DOT = self.DOT.data[i]
#             if type(limit)==float:
#                 temp_DOT[temp_DOT>limit] = np.nan
#                 DOT_filt[i]=gs.geo_filter(temp_DOT,self,radius,mask=mask)
            if mask:
                temp_mask[self.DOT.mask[i,:,:]==False] = np.nan 
            # the DOT has to be premasked to remove land points
            # and limits -  this happens within
            DOT_filt[i]=gs.geo_convolve(
                    temp_DOT,self,radius,limits,mask=temp_mask)
        self.DOT_filt= dy.data_year(DOT_filt,self.dates)
        self.DOT_filt.build_mask()
        # DOT_filt now get post masked within dy object
        self.DOT_filt.build_static_mask(np.isfinite(self.mask))



    def get_currents(self,n_use = [0,True]):
    # takes the filtered DOT field and generates the desired currents
        geo_x = np.empty([self.n_t,self.m,self.n])
        geo_y = np.empty([self.n_t,self.m,self.n])
        omega=2.*np.pi/24./60./60.
        g = 9.8
        fcor = 2.*omega*np.sin(np.deg2rad(self.lats.T))
        if type(n_use[1]) == bool:
            n_use[1] = self.n_t
        for tt in range(n_use[0],n_use[1]):
            g1,g2= gs.geo_gradient(self.DOT_filt.data[tt],self)
            geo_y[tt] = g1*g/fcor
            geo_x[tt] = -g2*g/fcor
        self.geo_currents = dy.vec_data_year(geo_x,geo_y,self.dates)
        self.geo_currents.build_mask()
        # geo_currents now get post masked within dy object
        self.geo_currents.build_static_mask(np.isfinite(self.mask))




# First lets make a class for a time periods tracks etc
class CS_tracks(gs.grid_set):
# will make one of these at a time point (as a datetime) defined by timestart
# then process through the length of period (a time delta/or 'month' 'month/4' '10day' option)
# then write what we've done with the tracks (options needed here np/netcdf/etc)
# then dump them
# optional current processing and saving too
# optional multiple geoids to process from
# then update the time point by length period (initally from time period)
    def __init__(self,period,time_start,mplot):
        super().__init__(mplot)
        self.time = time_start
        self.period = period 
        # here we can do clever time period stuff 
        # to make sure we fill months/years correctly
        self.files = False
        self.LRM_tracks = False
        self.SAR_tracks = False
        self.SARIN_tracks = False
        self.binned = False
        self.offset = False
        self.saved = False
        self.grid = False
        self.gridinfo = False
        self.masked = False

    def print_time(self):
        print('Current time is '+self.time.strftime('%Y%m%d'))

#    def make_mask(self,mask_array,):
#        # puts in a lon lat grid for binning 
#        # make make sure you keep hold of regridding projs
#
#
    def find_tracks(self,CS2_path):
	# given the time and the period return a list of the tracks
	# make sure we save that we have the tracks
        self.LRM   = Track_list(self.time, self.period, CS2_path,'_LRM/elev/CS')
        self.SAR   = Track_list(self.time, self.period, CS2_path,'_SAR/elev/CS')
        self.SARIN = Track_list(self.time, self.period, CS2_path,'_SARIN/elev/CS')
        self.files = True

    def make_geoids(self,geoid,geoid_dir,extension = '.geoid',mode='b'):       
        # now calls external function for efficiency
        self.LRM.make_geoids(geoid,geoid_dir,extension,mode)
        self.SAR.make_geoids(geoid,geoid_dir,extension,mode)
        self.SARIN.make_geoids(geoid,geoid_dir,extension,mode)

    def load_tracks(self,load_geoid,geoid_dir,extension = '.geoid'):
	# given the list of tracks in each data class
	# load all the data from the files found
        if (not self.LRM_tracks) and self.LRM.found_files:
            print('Loading LRM')
            self.LRM.get_data_from_CS_list(self.mplot,[1,2],load_geoid,geoid_dir,extension)
            self.LRM_tracks = True
        if (not self.SAR_tracks) and self.SAR.found_files:
            print('Loading SAR')
            self.SAR_o, self.SAR_l = self.SAR.get_data_from_CS_list_2stypes(self.mplot,[1],[2],load_geoid,geoid_dir,extension)
            self.SAR_tracks = True
        if (not self.SARIN_tracks) and self.SARIN.found_files:
            print('Loading SARIN')
            self.SARIN.get_data_from_CS_list(self.mplot,[1,2],load_geoid,geoid_dir,extension)
            self.SARIN_tracks = True


    def bin_tracks(self,geoid,SH=False):
	# given the list of tracks in each data class
	# load all the data from the files found
        if self.LRM_tracks:
            print('Binning LRM')
            self.LRM.bin_the_tracks(self,geoid,SH=SH)
        if self.SAR_tracks:
            print('Binning SAR_o')
            self.SAR_o.bin_the_tracks(self,geoid,SH=SH)
            print('Binning SAR_l')
            self.SAR_l.bin_the_tracks(self,geoid,SH=SH)
        if self.SARIN_tracks:
            print('Binning SARIN')
            self.SARIN.bin_the_tracks(self,geoid,SH=SH)
        if not geoid:
            self.LRM.DOT_bin = []
            self.SAR_o.DOT_bin = []
            self.SAR_l.DOT_bin = []
            self.SARIN.DOT_bin = []

    def calc_offsets(self,mask):
        # if we've binned the tracks, find areas where they overlap
        # create gridded offset array
        # create constant offset for each track type
        # offset 0 = LRM_sla_binned - SAR_o_sla_binned
        # offset 1 = SAR_o_sla_binned - SAR_l_sla_binned
        # offset 2 = SAR_l_sla_binned - SARIN_sla_binned
        # so need a difference between the means for
        if not self.masked:
            print('Needs a mask: make one!')
        else:
            # LRM is always zero - the baseline
            msk = (self.LRM.sla_bin_count>0) & (self.SAR_o.sla_bin_count>0)
            self.SAR_o.offset = (self.LRM.sla_bin - self.SAR_o.sla_bin)*msk*mask
            msk = (self.SAR_o.sla_bin_count>0) & (self.SAR_l.sla_bin_count>0)
            self.SAR_l.offset = (self.SAR_o.sla_bin - self.SAR_l.sla_bin)*msk*mask
            msk = (self.SAR_l.sla_bin_count>0) & (self.SARIN.sla_bin_count>0)
            self.SARIN.offset = (self.SAR_l.sla_bin - self.SARIN.sla_bin)*msk*mask

    def save_offsets_npz(self,file):
        # if we've binned the tracks, and calculated the offsets
        # save them!
        # all modes: mean DOT_bin, sal_counts
        # all except LRM: offset arrays
        # + land mask
        # plus m,n dxRes dyRes for checking
        if self.LRM.binned:
            # save lat/lon pts 
            np.savez(file,
                LRM_DOT_bin = self.LRM.DOT_bin,
                SAR_o_DOT_bin = self.SAR_o.DOT_bin,
                SAR_l_DOT_bin = self.SAR_l.DOT_bin,
                SARIN_DOT_bin = self.SARIN.DOT_bin,
                LRM_sla_bin_count = self.LRM.sla_bin_count,
                SAR_o_sla_bin_count = self.SAR_o.sla_bin_count,
                SAR_l_sla_bin_count = self.SAR_l.sla_bin_count,
                SARIN_sla_bin_count = self.SARIN.sla_bin_count,
                SAR_o_offset = self.SAR_o.offset,
                SAR_l_offset = self.SAR_l.offset,
                SARIN_offset = self.SARIN.offset,
                dxRes = self.dxRes,
                dyRes = self.dyRes,
                m = self.m,
                n = self.n)
            print("Binned data saved in "+file)
            self.saved = True
        else:
            print("Tracks aren't binned, data not saved")


    def load_offsets_npz(self,file):
        # if we've binned the tracks, and calculated the offsets
        # save them!
        # all modes: mean DOT_bin, sal_counts
        # all except LRM: offset arrays
        # + land mask
        # plus m,n dxRes dyRes for checking
        if self.LRM.binned:
            # save lat/lon pts 
            print("Data appears to already exist, do you really want over write?")
        else:
            npzfile =  np.load(file)
            self.LRM.DOT_bin = npzfile["LRM_DOT_bin"]
            self.SAR_o.DOT_bin = npzfile["SAR_o_DOT_bin"]
            self.SAR_l.DOT_bin = npzfile["SAR_l_DOT_bin"]
            self.SARIN.DOT_bin = npzfile["SARIN_DOT_bin"]
            self.LRM.sla_bin_count = npzfile["LRM_sla_bin_count"]
            self.SAR_o.sla_bin_count = npzfile["SAR_o_sla_bin_count"]
            self.SAR_l.sla_bin_count = npzfile["SAR_l_sla_bin_count"]
            self.SARIN.sla_bin_count = npzfile["SARIN_sla_bin_count"]
            self.SAR_o.offset = npzfile["SAR_o_offset"]
            self.SAR_l.offset = npzfile["SAR_l_offset"]
            self.SARIN.offset = npzfile["SARIN_offset"]
            self.dxRes = npzfile["dxRes"]
            self.dyRes = npzfile["dyRes"]
            m = npzfile["m"]
            n = npzfile["n"]
            print("Loaded data saved from "+file)
            self.binned = True

# after the save dump, and move one
    def next_time(self):
    # delete everyhting made sofar if saved
        if self.saved:
            
            # be a bit more clever about clearing arrays
            # maybe reuse??
            # Tracks
            self.LRM.clear
            del self.LRM
            self.SAR.clear
            del self.SAR
            self.SAR_o.clear
            del self.SAR_o
            self.SAR_l.clear
            del self.SAR_l
            self.SARIN.clear
            del self.SARIN
            # flags
            self.files = False
            self.LRM_tracks = False
            self.SAR_tracks = False
            self.SARIN_tracks = False
            self.binned = False
            self.offset = False
            self.saved = False
            
            gc.collect()

            # next time point
            self.time += self.period


# now putting all the tracks in a seperate class

class Track_list:
# this function gets the files 
# now in a dataframe for speed - individual arrays no longer used
    def __init__(self,time_start, period, CS2_path,type_path):
        files = []
        self.time = time_start
        self.period = period
        self.read = False
        self.binned = False
        self.g_files = False
        time_use = time_start
        while (time_use - (time_start + period)).days < 0:
            files.append(glob.glob(CS2_path+time_use.strftime('%Y%m')
                +type_path+'_*_'+time_use.strftime('%Y%m%d')+'*.elev'))
            time_use += relativedelta(days=1)
        #load in files 
        if (np.size(files)==0):
            print ('no data this year')
            self.found_files = False
        else:
            self.found_files = True
            # finish by flattening the list of files
            self.files = list(itertools.chain(*files))
    
    def get_data_from_CS_list_2stypes(self,mplot,st1,st2,load_geoid,geoid_dir,extension):
        # returns two Track_lists from one from surface types
        newc1 = copy.copy(self)
        newc2 = copy.copy(self)
        # now calls external function for efficiency
        # now need to produce two Tracks with the data split
        # now in  pandas for efficiency
        # col ID [st,val,lat,lon,elev_abs,elev_mean]
        # col ID usecols=[0,1,5,6,7,8]
        # col ID [lon,lat,geoid]
        # return li, xpts,ypts,lig, geoid_flag
        (newc1.pd_cs,newc1.xpts, newc1.ypts, newc1.pd_gd, newc1.geoid_flag,
         newc2.pd_cs,newc2.xpts, newc2.ypts, newc2.pd_gd, newc2.geoid_flag)  = data_from_list_pd_2st(self.files,mplot,st1,st2,load_geoid,geoid_dir,extension)
        newc1.geoid_flag = np.array(newc1.geoid_flag)
        newc2.geoid_flag = np.array(newc2.geoid_flag)
#         newc1.read = True
#         newc2.read = True
        if load_geoid:
            # note that following lists may be of different sizes due to geoid calc
            msk = newc1.geoid_flag==1.0
            DOT = newc1.pd_cs[7].values-newc1.pd_gd[2].values
            newc1.DOT = DOT[msk]
            newc1.xptsg = newc1.xpts[msk]
            newc1.yptsg = newc1.ypts[msk]
            msk = newc2.geoid_flag==1.0
            DOT = newc2.pd_cs[7].values-newc2.pd_gd[2].values
            newc2.DOT = DOT[msk]
            newc2.xptsg = newc2.xpts[msk]
            newc2.yptsg = newc2.ypts[msk]

        # and output the two new classes all filled up with tracks
        return newc1, newc2

    def get_data_from_CS_list(self,mplot,st,load_geoid,geoid_dir,extension):       
        # now calls external function for efficiency
        # now in  pandas for efficiency
        # col ID [0,1,5,6,7,8]
        # col ID [st,val,lat,lon,elev_abs,elev_mean]
        # col ID [lon,lat,geoid]
        # return li, xpts,ypts,lig, geoid_flag
        self.pd_cs,self.xpts, self.ypts, self.pd_gd, self.geoid_flag = data_from_list_pd(self.files,mplot,st,load_geoid,geoid_dir,extension)
        self.geoid_flag = np.array(self.geoid_flag)
        self.read = True
        if load_geoid:
            # note that following lists may be of different sizes due to geoid calc
            msk = self.geoid_flag==1.0
            DOT = self.pd_cs[7].values-self.pd_gd[2].values
            self.DOT = DOT[msk]
            self.xptsg = self.xpts[msk]
            self.yptsg = self.ypts[msk]


    def bin_the_tracks(self,CS_track,geoid,SH=False,check_geoid = False):
        # takes the track data read in and bins it on the parent grid
        # the info needed for binning is xpts info - nx/ny and range - x/y min/max from parent
        # need to produce mean and count from measurements
        if self.binned:
            print('Binned already!!!')
        else:
            edges_x = CS_track.xpts[0,:] - CS_track.dxRes/2
            edges_y = CS_track.ypts[:,0] - CS_track.dyRes/2
            if SH:
                edges_x = np.append(edges_x,CS_track.xpts[0,-1] - CS_track.dxRes)
                edges_y = np.append(edges_y,CS_track.ypts[-1,0] - CS_track.dyRes)
                edges_x = np.flip(edges_x)
                edges_y = np.flip(edges_y)
            else:
                edges_x = np.append(edges_x,CS_track.xpts[0,-1] + CS_track.dxRes)
                edges_y = np.append(edges_y,CS_track.ypts[-1,0] + CS_track.dyRes)
                # change the last entry and flip
#                 edges_x[-1] = edges_x[-1] - 1.5*CS_track.dxRes
#                 edges_x[-1] = edges_x[-1] - 1.5*CS_track.dxRes
            # print(edges_x)
            # print(edges_y)
            ret = stats.binned_statistic_2d( self.xpts, self.ypts, self.pd_cs[7].values - self.pd_cs[8].values,
	    		statistic='mean', bins=[edges_x,edges_y]) #150km bins at this resolution
            self.sla_bin = ret.statistic
            ret = stats.binned_statistic_2d( self.xpts, self.ypts, None,
	    		statistic='count', bins=[edges_x,edges_y]) #150km bins at this resolution
            if SH:
                self.sla_bin_count = np.flip(ret.statistic)
            else:
                self.sla_bin_count = ret.statistic
            if geoid:
                ret = stats.binned_statistic_2d( self.xptsg, self.yptsg, self.DOT,
	    		statistic='mean', bins=[edges_x,edges_y]) #150km bins at this resolution
                if SH:
                    self.DOT_bin = np.flip(ret.statistic)
                else:
                    self.DOT_bin = ret.statistic
            if check_geoid:
                msk = self.geoid_flag==1.0
                ret = stats.binned_statistic_2d( self.xptsg, self.yptsg, self.pd_gd[2].values[msk],
	    		statistic='mean', bins=[edges_x,edges_y]) #150km bins at this resolution
                if SH:
                    self.geoid_bin = np.flip(ret.statistic)
                else:
                    self.geoid_bin = ret.statistic
            self.binned = True


    def make_geoids(self,geoid_file,geoid_dir,extension = '.geoid',mode = 'n'):
        # takes the file list and makes corresponding geoid files that line up
        # geoid is a netcdf file that matches -  check it
        # extension is the extra name
        if (not self.g_files):
            # shutil.copy(geoid_file,'GRID_temp.nc')
            for filename in self.files:
                file_g = filename.split('elev/')[1]
                file_write = geoid_dir+file_g+extension
                # shutil.copyfile(self.files[j],'./SARtrack_input.elev')
                cmd = "awk '{print $7, $6}' "+filename+" > "+geoid_dir+"SARlong_lat.xy"
                result = run(cmd)
                cmd = "gmt grdtrack "+geoid_dir+"SARlong_lat.xy -G"+geoid_file+" -N  -n"+mode+" > "+file_write #interpolation
                result = run(cmd)
                del result
                # shutil.copyfile('./SARlong_lat.xyg', self.files[j]+'.geoid')
        self.g_files = True
        print("made the geoid files")

    def trash_geoids(self,geoid_dir,extension = '.geoid'):
        # takes the file list and deletes the geoid files (if they exist)
        if self.g_files:
            for filename in self.files:
                file_g = filename.split('elev/')[1]
                file_write = geoid_dir+file_g+extension
                exists = os.path.isfile(file_write)
                if exists:
                    cmd = "rm "+file_write
                    result = run(cmd)
        self.g_files = False
        
    def clear(self,geoid=True):
        # empty the pd dfs for the next time step
        if self.read and self.binned:
            self.pd_cs = self.pd_cs.iloc[0:0]
            del self.pd_cs
            del self.xpts
            del self.ypts
            del self.sla_bin
            del self.sla_bin_count
            if geoid:
                self.pd_gd = self.pd_gd.iloc[0:0]
                del self.pd_gd
                del self.xptsg
                del self.yptsg
                del self.DOT
            self.read = False

@ jit
def data_from_list_pd(files,mplot,st,load_geoid,geoid_dir,extension):
    """
    returns two pd datatrames from a list of files
    first frame is from the files list with surface type st
    second frame is the co-named geoid file - if load_geiod is true
    also to return the mapped x/y pts for gridding
    """

    li = pd.DataFrame()    
    lig = pd.DataFrame()    
#     geoid_flag = []
    geoid_flag = np.array([])
    xpts = np.array([])
    ypts = np.array([])
#     xpts = []
#     ypts = []

    # Fill lists for each mode
    for filename in files:
        b = os.path.getsize(filename)
        if b > 200:
            df = pd.read_csv(filename,delim_whitespace=True,header=None, usecols=[0,1,5,6,7,8])
            # filter the df depending on the st
            df_f = df[0].isin(st)&df[1]==1
            df_a = df[df_f]
            ii = df_a.shape[0]
            jj = df.shape[0]
            li = li.append(df_a)
            x, y = mplot(df_a.values[:,3],  df_a.values[:,2])
            xpts = np.append(xpts,x)
            ypts = np.append(ypts,y)
#             xpts.extend(x)
#             ypts.extend(y)
            if load_geoid:
                file_g = filename.split('elev/')[1]
                file_geoid = geoid_dir+file_g+extension
                df = pd.read_csv(file_geoid,delim_whitespace=True,header=None, usecols=[0,1,2])
                if df.shape[0] == jj:
                    df_a = df[df_f]
                    lig = lig.append(df_a)
                    geoid_flag = np.append(geoid_flag,np.ones([ii]))
#                     geoid_flag.extend(np.ones([ii]))
                else:
                    lig = lig.append(pd.DataFrame(np.zeros([ii,3])))
                    geoid_flag = np.append(geoid_flag,np.zeros([ii]))
#                     geoid_flag.extend(np.zeros([ii]))
    # Transform long and lat into 2D gridded points so we can plot them
    # lons in pd column 2
    # lats in pd column 3
    # xptsg, yptsg = mplot(lig.values[0], lig.values[1])
    # xpts = np.array(xpts)
    # ypts = np.array(ypts)
    return li, xpts,ypts,lig, geoid_flag
    # return li, lig, geoid_flag

# @ jit
def data_from_list_pd_2st(files,mplot,st1,st2,load_geoid,geoid_dir,extension):
    """
    returns two pd datatrames from a list of files
    first frame is from the files list with surface type st
    second frame is the co-named geoid file - if load_geiod is true
    also to return the mapped x/y pts for gridding

    This version gives two seperate outputs for two surface types 
     -- mainly for SAR ocean/lead
    """

    li1 = pd.DataFrame()    
    lig1 = pd.DataFrame()    
    geoid_flag1 = np.array([])
    xpts1 = np.array([])
    ypts1 = np.array([])

    li2 = pd.DataFrame()    
    lig2 = pd.DataFrame()    
    geoid_flag2 = np.array([])
    xpts2 = np.array([])
    ypts2 = np.array([])

    # Fill lists for each mode
    for filename in files:
        b = os.path.getsize(filename)
        if b > 200:
            df = pd.read_csv(filename,delim_whitespace=True,header=None, usecols=[0,1,5,6,7,8])
            # filter the df depending on the st
            df_f = df[0].isin(st1)&df[1]==1
            df_a = df[df_f]
            ii = df_a.shape[0]
            jj = df.shape[0]
            li1 = li1.append(df_a)
            x, y = mplot(df_a.values[:,3],  df_a.values[:,2])
            xpts1 = np.append(xpts1,x)
            ypts1 = np.append(ypts1,y)
            if load_geoid:
                file_g = filename.split('elev/')[1]
                file_geoid = geoid_dir+file_g+extension
                dfg = pd.read_csv(file_geoid,delim_whitespace=True,header=None, usecols=[0,1,2])
                if dfg.shape[0] == jj:
                    df_a = dfg[df_f]
                    lig1 = lig1.append(df_a)
                    geoid_flag1 = np.append(geoid_flag1,np.ones([ii]))
#                     geoid_flag1.extend(np.ones([ii]))
                else:
                    lig1 = lig1.append(pd.DataFrame(np.zeros([ii,3])))
                    geoid_flag1 = np.append(geoid_flag1,np.zeros([ii]))
                    # geoid_flag1.extend(np.zeros([ii]))
            # now for st2
            df_f = df[0].isin(st2)&df[1]==1
            df_a = df[df_f]
            ii = df_a.shape[0]
            li2 = li2.append(df_a)
            x, y = mplot(df_a.values[:,3],  df_a.values[:,2])
            xpts2 = np.append(xpts2,x)
            ypts2 = np.append(ypts2,y)
            if load_geoid:
#                 print(dfg.shape,jj)
                if dfg.shape[0] == jj:
                    df_a = dfg[df_f]
                    lig2 = lig2.append(df_a)
#                     geoid_flag2.extend(np.ones([ii]))
                    geoid_flag2 = np.append(geoid_flag2,np.ones([ii]))
                else:
                    lig2 = lig2.append(pd.DataFrame(np.zeros([ii,3])))
#                     geoid_flag2.extend(np.zeros([ii]))
                    geoid_flag2 = np.append(geoid_flag2,np.zeros([ii]))
    # Transform long and lat into 2D gridded points so we can plot them
    # lons in pd column 2
    # lats in pd column 3
    # xpts,  ypts  = mplot(li.values[:,3],  li.values[:,2])
    # xptsg, yptsg = mplot(lig.values[0], lig.values[1])
    # xpts = np.array(xpts)
    # ypts = np.array(ypts)
    return li1, xpts1,ypts1,lig1, geoid_flag1,li2, xpts2,ypts2,lig2, geoid_flag2
    # return li, lig, geoid_flag

@jit
def data_from_list_eff(files,mplot,load_geoid,extension):

    # initialise lists
    surface_type=[]
    validity=[]
    lats=[]
    lons=[]
    time=[]
    concentration=[]
    sea_ice_type=[]
    elev_abs=[]
    elev_mean=[]
    geoid=[]
    geoid_flag=[]
    # xpts=[]
    # ypts=[]

    
    # Fill lists for each mode
    for j in range(np.size(files)):
        # print (j, np.size(files))
        data = np.loadtxt(files[j])
        # Fill arrays
        ii,jj = data.shape
        if (len(data.shape)>1)&(data.shape[0]>=1):
            surface_type.extend(data[:,0])
            validity.extend(data[:,1])
            lats.extend(data[:,5])
            lons.extend(data[:,6])
            #time.extend(data[:,4])
            #concentration.extend(data[:,11])
            #sea_ice_type.extend(data[:,12])
            elev_abs.extend(data[:,7])
            elev_mean.extend(data[:,8])
        elif (data.shape[0]>=1):
            surface_type.append(data[0])
            validity.append(data[1])
            lats.append(data[5])
            lons.append(data[6])
            #time.append(data[4])
            #concentration.append(data[11])
            #sea_ice_type.append(data[12])
            elev_abs.append(data[7])
            elev_mean.append(data[8])
        if load_geoid:
            file = files[j]+extension
            data = np.loadtxt(file)
            # print(ii,jj,data.shape)
            if np.shape(data)[0] == 0:
                geoid.extend(np.zeros(ii))
                geoid_flag.extend(np.zeros(ii))
                # print(np.shape(geoid),np.shape(surface_type))
            elif (len(data.shape)>1)&(data.shape[0]>=1):
                geoid.extend(data[:,2])
                geoid_flag.extend(np.ones(ii))
            elif (data.shape[0]>=1):
                geoid.append(data[2])
                geoid_flag.append(1.0)
    surface_type = np.array(surface_type)
    validity = np.array(validity)
    lats = np.array(lats)
    lons = np.array(lons)
    time = np.array(time)
    concentration = np.array(concentration)
    sea_ice_type = np.array(sea_ice_type)
    elev_abs = np.array(elev_abs)
    elev_mean = np.array(elev_mean)
    geoid = np.array(geoid)
    geoid_flag = np.array(geoid_flag)

    # Transform long and lat into 2D gridded points so we can plot them
    xpts, ypts = mplot(lons, lats)
    # xpts = np.array(xpts)
    # ypts = np.array(ypts)
    

    return surface_type,validity,lats,lons,time,concentration,sea_ice_type,elev_abs,elev_mean,xpts, ypts,geoid,geoid_flag


@jit
def data_from_list(files,mplot,surf_type):

    surf_type = np.array(surf_type)
    # initialise lists
    surface_type=[]
    validity=[]
    lats=[]
    lons=[]
    time=[]
    concentration=[]
    sea_ice_type=[]
    elev_abs=[]
    elev_mean=[]

    
    # Fill lists for each mode
    for j in range(np.size(files)):
        # print (j, np.size(files))
        data = np.loadtxt(files[j])
        # Fill arrays
        ii,jj = data.shape
        if len(data.shape)>1:
            nn,jj = data.shape
            for ii in range(nn):
                if ((data.shape[0]>=1)&(surf_type == data[ii,0]).any()&
                (data[ii,1]==1.0)):
                    surface_type.append(data[ii,0])
                    validity.append(data[ii,1])
                    lats.append(data[ii,5])
                    lons.append(data[ii,6])
                    time.append(data[ii,4])
                    concentration.append(data[ii,11])
                    sea_ice_type.append(data[ii,12])
                    elev_abs.append(data[ii,7])
                    elev_mean.append(data[ii,8])
        else:
            if ((data.shape[0]>=1)&(surf_type == data[0]).any()&
                (data[1]==1.0)):
                surface_type.append(data[0])
                validity.append(data[1])
                lats.append(data[5])
                lons.append(data[6])
                time.append(data[4])
                concentration.append(data[11])
                sea_ice_type.append(data[12])
                elev_abs.append(data[7])
                elev_mean.append(data[8])
    surface_type = np.array(surface_type)
    validity = np.array(validity)
    lats = np.array(lats)
    lons = np.array(lons)
    time = np.array(time)
    concentration = np.array(concentration)
    sea_ice_type = np.array(sea_ice_type)
    elev_abs = np.array(elev_abs)
    elev_mean = np.array(elev_mean)

    # Transform long and lat into 2D gridded points so we can plot them
    xpts, ypts = mplot(lons, lats)
    # xpts = np.array(xpts)
    # ypts = np.array(ypts)
    
    flag=np.ones((len(xpts)))

    return surface_type,validity,lats,lons,time,concentration,sea_ice_type,elev_abs,elev_mean,xpts, ypts,flag



